# Preguntas para el cliente

Todo lo marcado como [À CONFIRMER] en las páginas, agrupado por tema. Cuando se responda, se cambia en `config/cliente.yml` / `config/zonas.yml` o en el `fr.md` de la página y se vuelve a ejecutar `python3 scripts/construir_pagina.py`.

## Datos del cabinet y NAP

- **Dirección exacta: el sitio y la ficha de Google dicen «Rämismatte 21, 3232 Ins»; el encargo decía 31. ¿Cuál es la correcta?**
- `/physio-a-sugiez/` — [À CONFIRMER : liste des villages et jours de passage dans le Vully] · «Notre site mentionne déjà des visites à domicile à Sugiez, Praz, Môtier, Lugnorre et Guévaux ; pour Nant, Salavaux ou Cudrefin, demandez-nous simplement si votre adresse est desservie [À CONFIRMER : liste des villages et jours de passage dans le Vully].»
- `/physio-a-la-neuveville/` — [À CONFIRMER : localités desservies et jours de passage] · «Nous n'avons pas encore de tournée fixe annoncée dans ce secteur : indiquez-nous votre adresse et nous vous dirons ce qui est possible [À CONFIRMER : localités desservies et jours de passage].»
- `/physio-a-la-neuveville/` — [À CONFIRMER : couverture du Plateau de Diesse et du Landeron] · «Contactez-nous avec votre adresse [À CONFIRMER : couverture du Plateau de Diesse et du Landeron].»
- `/physio-a-yverdon/` — [À CONFIRMER : déplacements à Yverdon-les-Bains possibles ou non] · «Notre unique adresse se trouve à Ins (Rämismatte 21), à environ 43 km en ligne droite, et les visites à domicile à Yverdon sont [À CONFIRMER : déplacements à Yverdon-les-Bains possibles ou non].»

## Horarios y plazos

- **Horario real: la ficha de Google dice lunes a viernes de 8:30 a 19:30; el sitio actual, «jusqu'à 20h». ¿Y el plazo habitual para la primera cita?**
- `/` — [À CONFIRMER] · «Les horaires d'ouverture et les délais de rendez-vous sont indiqués lors de la réservation : [À CONFIRMER].»
- `/a-propos-de-nous/` — [À CONFIRMER : lun–ven 8h30–19h30 ou jusqu'à 20h] · «Horaires : [À CONFIRMER : lun–ven 8h30–19h30 ou jusqu'à 20h].»
- `/physio-a-sugiez/` — [À CONFIRMER : arrêt et horaires à vérifier pour Sugiez] · «Notre site indique aussi un accès en train par la ligne Fribourg–Morat–Ins [À CONFIRMER : arrêt et horaires à vérifier pour Sugiez].»
- `/physio-a-lyss/` — [À CONFIRMER] · «Délai pour un premier rendez-vous : [À CONFIRMER].»
- `/physio-a-bienne/` — [À CONFIRMER : localités desservies, jours de passage et délai du premier rendez-vous] · «Autour de la ville, Nidau, Brügg, Port, Ipsach et Evilard sont des communes voisines que nous pourrions inclure dans nos tournées [À CONFIRMER : localités desservies, jours de passage et délai du premier rendez-vous].»
- `/physio-a-bienne/` — [À CONFIRMER : délai du premier rendez-vous] · «Le délai pour la première séance dépend de nos disponibilités [À CONFIRMER : délai du premier rendez-vous].»
- `/physio-a-fribourg/` — [À CONFIRMER : délai du premier rendez-vous] · «Le délai pour la première séance est à vérifier avec nous [À CONFIRMER : délai du premier rendez-vous].»
- `/physio-a-payerne/` — [À CONFIRMER : localités desservies, jours de passage et délai du premier rendez-vous] · «Les jours où nous passons dans la région restent à fixer [À CONFIRMER : localités desservies, jours de passage et délai du premier rendez-vous].»
- `/physio-a-morat/` — [À CONFIRMER : domicile à Morat et délai pour une première séance] · «Oui, dès que vous avez une ordonnance de physiothérapie, nous pouvons prendre le relais au cabinet ou, si c'est nécessaire, à domicile [À CONFIRMER : domicile à Morat et délai pour une première séance].»
- `/physio-a-chietres/` — [À CONFIRMER : déplacements à Chiètres et délai pour un premier rendez-vous] · «C'est précisément le type de situation où le domicile est utile [À CONFIRMER : déplacements à Chiètres et délai pour un premier rendez-vous].»
- `/physio-a-estavayer/` — [À CONFIRMER : délai pour une première séance] · «Avec l'ordonnance de physiothérapie remise par le médecin, nous pouvons organiser la suite de votre rééducation [À CONFIRMER : délai pour une première séance].»
- `/physio-a-yvonand/` — [À CONFIRMER : délai pour une première séance et domicile possible à Yvonand] · «Oui, la rééducation peut commencer dès réception de l'ordonnance de physiothérapie [À CONFIRMER : délai pour une première séance et domicile possible à Yvonand].»
- `/physio-a-yverdon/` — [À CONFIRMER : couverture de ces localités, jours de passage et délai du premier rendez-vous] · «Une prise en charge à Yverdon ou dans les communes voisines, comme Grandson, Montagny-près-Yverdon, Cheseaux-Noréaz ou Treycovagnes, reste donc [À CONFIRMER : couverture de ces localités, jours de passage et délai du premier rendez-vous].»
- `/physio-a-lausanne/` — [À CONFIRMER : couverture, fréquence et délai du premier rendez-vous] · «Les éventuels jours de passage dans l'agglomération lausannoise sont [À CONFIRMER : couverture, fréquence et délai du premier rendez-vous].»
- `/reservation-en-ligne/` — [À CONFIRMER] · «Horaires : du lundi au vendredi, de 8 h 30 à 19 h 30 [À CONFIRMER].»
- `/reservation-en-ligne/` — [À CONFIRMER] · «Délai d'annulation : [À CONFIRMER].»

## Atención a domicilio por localidad

- **¿En qué localidades hacen visitas a domicilio, qué días y con qué plazo? (Las zonas del lote B — Morat, Chiètres, Estavayer, Yvonand, Yverdon y Lausanne — no se publican hasta confirmarlo.)**
- `/physio-a-sugiez/` — [À CONFIRMER : domicile toujours proposé à Sugiez] · «Vous pouvez venir au cabinet ou, sur ordonnance médicale, recevoir votre physio chez vous dans le Mont-Vully [À CONFIRMER : domicile toujours proposé à Sugiez].»
- `/physio-a-sugiez/` — [À CONFIRMER : jours de passage dans le Mont-Vully] · «Les jours de passage restent à fixer avec vous [À CONFIRMER : jours de passage dans le Mont-Vully].»
- `/physio-a-neuchatel/` — [À CONFIRMER : zone desservie à domicile] · «Vous cherchez un physiothérapeute depuis Neuchâtel ? Physio Activa vous reçoit dans son cabinet d'Ins, à environ 13,4 km en ligne droite de la ville, et propose des séances à domicile en ville et dans les quartiers voisins [À CONFIRMER : zone desservie à domic»
- `/physio-a-neuchatel/` — [À CONFIRMER : communes du Littoral desservies et jours de passage] · «Les communes du Littoral comme Hauterive, Saint-Blaise, La Tène (Marin-Epagnier), Auvernier ou Peseux sont proches, mais leur prise en charge à domicile doit être vérifiée au cas par cas [À CONFIRMER : communes du Littoral desservies et jours de passage].»
- `/physio-a-la-neuveville/` — [À CONFIRMER : domicile à La Neuveville] · «Physio Activa vous accueille à Ins et peut envisager des visites à domicile [À CONFIRMER : domicile à La Neuveville].»
- `/physio-a-avenches/` — [À CONFIRMER : déplacements à Avenches] · «Selon votre situation, la physiothérapie peut se faire au cabinet ou à votre domicile [À CONFIRMER : déplacements à Avenches].»
- `/physio-a-avenches/` — [À CONFIRMER : villages desservis autour d'Avenches et jours de passage] · «Salavaux, au bord du lac de Morat, est aussi proche du Vully ; pour les autres villages, la possibilité d'un passage à domicile reste à confirmer [À CONFIRMER : villages desservis autour d'Avenches et jours de passage].»
- `/physio-a-avenches/` — [À CONFIRMER : Faoug, Domdidier, Donatyre, Oleyres] · «Ces villages entourent Avenches, mais nous devons encore confirmer s'ils font partie de notre zone à domicile [À CONFIRMER : Faoug, Domdidier, Donatyre, Oleyres].»
- `/physio-a-lyss/` — [À CONFIRMER : domicile à Lyss] · «Vous habitez Lyss et vous cherchez un physiothérapeute qui vous suive en français ? Notre cabinet se trouve à Ins, à environ 17 km en ligne droite, et des visites à domicile à Lyss sont possibles [À CONFIRMER : domicile à Lyss].»
- `/physio-a-lyss/` — [À CONFIRMER : localités desservies et jours de passage] · «Au-delà de la commune elle-même, nous pouvons envisager des déplacements vers Aarberg, Kappelen, Worben, Busswil ou Grossaffoltern [À CONFIRMER : localités desservies et jours de passage].»
- `/physio-a-lyss/` — [À CONFIRMER : localités desservies] · «Ces localités voisines de Lyss font partie des zones que nous pouvons étudier pour des séances à domicile [À CONFIRMER : localités desservies].»
- `/physio-a-bienne/` — [À CONFIRMER : domicile à Bienne] · «Selon votre situation, une prise en charge à domicile peut aussi être organisée [À CONFIRMER : domicile à Bienne].»
- `/physio-a-bienne/` — [À CONFIRMER : localités desservies] · «Ces communes voisines de Bienne peuvent entrer dans nos déplacements à domicile [À CONFIRMER : localités desservies].»
- `/physio-a-fribourg/` — [À CONFIRMER : domicile à Fribourg] · «Après une opération ou en cas de mobilité réduite, recevoir son physiothérapeute chez soi à Fribourg peut simplifier la rééducation [À CONFIRMER : domicile à Fribourg].»
- `/physio-a-fribourg/` — [À CONFIRMER : localités desservies et jours de passage] · «En plus de la ville, Villars-sur-Glâne, Marly, Givisiez et Granges-Paccot sont les localités voisines que nous pourrions couvrir [À CONFIRMER : localités desservies et jours de passage].»
- `/physio-a-fribourg/` — [À CONFIRMER : localités desservies] · «Ces deux communes voisines de Fribourg font partie des zones envisagées pour les visites à domicile [À CONFIRMER : localités desservies].»
- `/physio-a-payerne/` — [À CONFIRMER : domicile à Payerne] · «Payerne se situe à environ 24,1 km en ligne droite de notre cabinet d'Ins ; pour les patients de la Broye, des séances à domicile peuvent être envisagées [À CONFIRMER : domicile à Payerne].»
- `/physio-a-payerne/` — [À CONFIRMER : domicile à Payerne] · «Depuis Payerne, vous pouvez choisir entre le cabinet d'Ins et le domicile [À CONFIRMER : domicile à Payerne].»
- `/physio-a-morat/` — [À CONFIRMER : déplacements à Morat] · «Vous habitez Morat et vous cherchez un physiothérapeute qui vous reçoit en français ? Le cabinet Physio Activa se trouve à Ins, à environ 8,7 km en ligne droite de la vieille ville, et des séances à domicile sont possibles selon les disponibilités [À CONFIRMER»
- `/physio-a-morat/` — [À CONFIRMER : localités desservies et jours de passage] · «Dans ce cas, nous pouvons envisager de venir chez vous à Morat, mais aussi à Meyriez, Muntelier, Greng, Courgevaux ou Galmiz [À CONFIRMER : localités desservies et jours de passage].»
- `/physio-a-morat/` — [À CONFIRMER : liste définitive des localités et jours de passage] · «Ces localités voisines de Morat font partie de la zone que nous envisageons de couvrir à domicile [À CONFIRMER : liste définitive des localités et jours de passage].»
- `/physio-a-chietres/` — [À CONFIRMER : visites à domicile à Chiètres] · «Nous vous recevons au cabinet et pouvons aussi nous déplacer chez vous [À CONFIRMER : visites à domicile à Chiètres].»
- `/physio-a-chietres/` — [À CONFIRMER : localités couvertes et jours de passage] · «Autour de Chiètres, les localités concernées seraient Fräschels, Ried bei Kerzers, Galmiz et Agriswil [À CONFIRMER : localités couvertes et jours de passage].»
- `/physio-a-chietres/` — [À CONFIRMER : séances possibles en allemand ?] · «Chez Physio Activa, les séances se déroulent en français ou en espagnol : une solution pratique pour les familles francophones ou hispanophones installées à Kerzers et dans les villages voisins [À CONFIRMER : séances possibles en allemand ?].»
- `/physio-a-chietres/` — [À CONFIRMER : liste des localités et jours de passage] · «Ce sont des villages voisins de Chiètres que nous souhaitons inclure dans nos tournées [À CONFIRMER : liste des localités et jours de passage].»
- `/physio-a-estavayer/` — [À CONFIRMER : domicile à Estavayer] · «Physio Activa vous accueille au cabinet d'Ins et étudie la possibilité de séances à domicile dans la Broye [À CONFIRMER : domicile à Estavayer].»
- `/physio-a-estavayer/` — [À CONFIRMER : couverture de ces localités et jours de passage] · «Pour Estavayer, cela pourrait concerner aussi Font, Cheyres-Châbles, Sévaz et Les Montets [À CONFIRMER : couverture de ces localités et jours de passage].»
- `/physio-a-estavayer/` — [À CONFIRMER : domicile à Estavayer] · «Si ce n'est pas le cas, le domicile peut être une option [À CONFIRMER : domicile à Estavayer].»
- `/physio-a-estavayer/` — [À CONFIRMER : localités desservies et jours de passage] · «Ces villages proches d'Estavayer pourraient être regroupés avec les visites à domicile du secteur [À CONFIRMER : localités desservies et jours de passage].»
- `/physio-a-yvonand/` — [À CONFIRMER : domicile à Yvonand] · «Une ordonnance de physiothérapie en poche et un domicile à Yvonand ? Physio Activa travaille depuis Ins, à environ 35,9 km en ligne droite, et vous propose des séances au cabinet ; le déplacement à domicile reste à confirmer pour votre secteur [À CONFIRMER : d»
- `/physio-a-yvonand/` — [À CONFIRMER : localités desservies et jours de passage] · «Chêne-Pâquier, Démoret, Rovray et Cheyres-Châbles seraient alors concernés [À CONFIRMER : localités desservies et jours de passage].»
- `/physio-a-yvonand/` — [À CONFIRMER : localités et jours de passage] · «Ces communes voisines d'Yvonand seraient regroupées avec les visites du secteur si le domicile y est proposé [À CONFIRMER : localités et jours de passage].»
- `/physio-a-yverdon/` — [À CONFIRMER : déplacements dans la région d'Yverdon et conditions] · «La réponse est [À CONFIRMER : déplacements dans la région d'Yverdon et conditions].»
- `/physio-a-lausanne/` — [À CONFIRMER : déplacements à Lausanne possibles ou non] · «Une prise en charge à domicile sur place est [À CONFIRMER : déplacements à Lausanne possibles ou non].»
- `/physio-a-lausanne/` — [À CONFIRMER : déplacements dans l'agglomération lausannoise] · «La réponse dépend de [À CONFIRMER : déplacements dans l'agglomération lausannoise].»
- `/douleur-de-hanche-protheses/` — [À CONFIRMER] · «La physiothérapie à domicile doit être mentionnée sur l'ordonnance [À CONFIRMER].»

## Equipo, titulaciones e idiomas

- **Titulación, formación y número de registro profesional (NAREG / RCC) de Francisco Díaz y Lucile Combes, y foto actualizada para la autoría.**
- **Idiomas: el sitio actual cita francés, alemán, portugués y español; ¿cuáles se ofrecen de verdad en consulta?**
- **Traductor del navegador (FR/DE/EN/PT/ES) retirado de la home: ¿quieren mantener versiones EN/PT/ES? La versión DE ya existe en /de/.**
- `/` — [À CONFIRMER] · «Francisco Díaz et Lucile Combes sont physiothérapeutes chez Physio Activa (formation et titres : [À CONFIRMER]).»
- `/` — [À CONFIRMER : titre et formation] · «[À CONFIRMER : titre et formation]»
- `/` — [À CONFIRMER : titre et formation] · «[À CONFIRMER : titre et formation]»
- `/a-propos-de-nous/` — [À CONFIRMER : titre et formation] · «[À CONFIRMER : titre et formation]»
- `/a-propos-de-nous/` — [À CONFIRMER : titre, formation et numéro d'enregistrement NAREG / RCC] · «Francisco est physiothérapeute [À CONFIRMER : titre, formation et numéro d'enregistrement NAREG / RCC].»
- `/a-propos-de-nous/` — [À CONFIRMER] · «Il parle français et espagnol, ainsi que portugais [À CONFIRMER].»
- `/a-propos-de-nous/` — [À CONFIRMER : titre et formation] · «[À CONFIRMER : titre et formation]»
- `/a-propos-de-nous/` — [À CONFIRMER : titre, formation et numéro d'enregistrement NAREG / RCC] · «Lucile est physiothérapeute [À CONFIRMER : titre, formation et numéro d'enregistrement NAREG / RCC].»
- `/a-propos-de-nous/` — [À CONFIRMER] · «Elle parle français et espagnol, ainsi que portugais [À CONFIRMER].»
- `/a-propos-de-nous/` — [À CONFIRMER : titres, formations, enregistrement professionnel] · «Leurs titres et formations sont précisés ici : [À CONFIRMER : titres, formations, enregistrement professionnel].»
- `/a-propos-de-nous/` — [À CONFIRMER] · «Le portugais est [À CONFIRMER].»
- `/physio-a-neuchatel/` — [À CONFIRMER : information tarifaire à communiquer] · «Pour le montant exact et une éventuelle participation de votre part, contactez-nous [À CONFIRMER : information tarifaire à communiquer].»

## Tarifas y sesiones

- `/` — [À CONFIRMER] · «La durée d'une séance est de [À CONFIRMER].»
- `/` — [À CONFIRMER] · «Pour toute question sur le tarif appliqué : [À CONFIRMER].»
- `/physio-a-payerne/` — [À CONFIRMER : montant indicatif par séance] · «En LAMal, seules la franchise et la quote-part restent à votre charge [À CONFIRMER : montant indicatif par séance].»
- `/physio-a-payerne/` — [À CONFIRMER : tarif en vigueur et date de changement] · «Pour connaître le tarif appliqué actuellement, contactez-nous [À CONFIRMER : tarif en vigueur et date de changement].»
- `/mal-de-dos-lombaire/` — [À CONFIRMER] · «Durée d'une séance : [À CONFIRMER].»
- `/douleur-cervicale-au-cou/` — [À CONFIRMER] · «Durée d'une séance : [À CONFIRMER].»
- `/lesions-de-lepaule/` — [À CONFIRMER] · «Durée d'une séance : [À CONFIRMER].»
- `/sciatique-hernie-discale/` — [À CONFIRMER] · «Durée d'une séance : [À CONFIRMER].»
- `/douleur-de-hanche-protheses/` — [À CONFIRMER] · «Le nombre de séances dépend de votre évolution et de l'ordonnance ; la durée d'une séance est de [À CONFIRMER] minutes.»

## Otros

- **Reseñas: la home muestra la nota real de Google (5,0 · 19 reseñas, 06.11.2026) con enlace a la ficha. ¿Quieren un widget oficial de reseñas?**
- **Logos de aseguradoras: la plantilla tenía nombres de ejemplo («Placeholders»); se ha quitado la sección. ¿Hay convenios o logos oficiales que mostrar?**
- **Destino de /online-termin-buchen/ (H1 en alemán): ¿301 a /de/ o a /reservation-en-ligne/?**
- **Fotos: ver pendientes_imagenes.md.**
- `/physio-a-neuchatel/` — [À CONFIRMER : fréquence et arrêt] · «Notre site mentionne la ligne de train Neuchâtel–Fribourg–Morat–Ins pour venir sans voiture [À CONFIRMER : fréquence et arrêt].»
